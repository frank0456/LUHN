﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mod10Check
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Inserisci il numero della carta di credito:");
            var ccnumber = Console.ReadLine();
            var risultato = Mod10.Mod10Check(ccnumber);
            if (risultato)
            {
                Console.WriteLine("La carta è valida!");
            }
            else
            {
                Console.WriteLine("La carta non è valida");
            }
            Console.ReadLine();
        }
    }
}
